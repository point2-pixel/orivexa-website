import "./globals.css";
export const metadata={title:"Orivexa AI",description:"Build a living knowledge graph for your company with AI."};
export default function RootLayout({children}:{children:React.ReactNode}){return(<html lang="en"><body>{children}</body></html>)}